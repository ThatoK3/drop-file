"""
credit_risk_ml_platform — Feast Feature Definitions
====================================================
Entities, data sources, feature views, and feature services.
All offline sources point to parquet files in MinIO written by the Spark ETL jobs.
Online store: Redis.

Import from anywhere:
    from feature_repo.features import (
        store,
        applicant, loan_facility, credit_bureau_profile, collateral_asset,
        fv_applicant_risk, fv_bureau, fv_facility, fv_collateral, fv_historical,
        svc_credit_scoring, svc_monitoring,
        FEATURE_COLS, TARGET_COL,
    )
"""

from datetime import timedelta
from pathlib import Path

from feast import (
    Entity,
    FeatureService,
    FeatureStore,
    FeatureView,
    Field,
)
from feast.infra.offline_stores.contrib.spark_offline_store.spark_source import SparkSource
from feast.types import Bool, Float32, Int64, String
from feast.value_type import ValueType

# ── Repo path ─────────────────────────────────────────────────────────────────
REPO_PATH = Path(__file__).parent

# ── MinIO bucket ──────────────────────────────────────────────────────────────
BUCKET = "feast-credit-risk-training"

# ── Feature columns used for training (no entity keys, no target) ─────────────
FEATURE_COLS = [
    # ApplicantRiskProfile
    "ApplicantRiskProfile__employment_stability_index",
    "ApplicantRiskProfile__payment_to_income_ratio",
    "ApplicantRiskProfile__demographic_risk_score",
    "ApplicantRiskProfile__income_proof_verification_score",
    "ApplicantRiskProfile__document_completeness_score",
    # BureauHistoryAggregated
    "BureauHistoryAggregated__payment_history_score",
    "BureauHistoryAggregated__enquiry_count_90d",
    "BureauHistoryAggregated__accounts_active_count",
    # FacilityRiskMetrics
    "FacilityRiskMetrics__facility_type_encoded",
    "FacilityRiskMetrics__tenure_months",
    "FacilityRiskMetrics__interest_rate_margin",
    # CollateralValuationFeatures
    "CollateralValuationFeatures__valuation_confidence_score",
    "CollateralValuationFeatures__ltv_after_valuation",
    "CollateralValuationFeatures__revaluation_frequency_months",
]

CATEGORICAL_COLS = [
    "ApplicantRiskProfile__age_band",
    "ApplicantRiskProfile__income_quintile",
    "ApplicantRiskProfile__existing_exposure_band",
    "ApplicantRiskProfile__employment_letter_nlp_flag",
    "BureauHistoryAggregated__adverse_listing_flag",
    "BureauHistoryAggregated__worst_status_12m",
    "FacilityRiskMetrics__expected_loss_band",
    "CollateralValuationFeatures__collateral_type_category",
    "CollateralValuationFeatures__insurance_coverage_flag",
]

TARGET_COL = "outcome_default_flag"

# ════════════════════════════════════════════════════════════════════════════════
# ENTITIES
# ════════════════════════════════════════════════════════════════════════════════

applicant = Entity(
    name="Applicant",
    join_keys=["applicant_id"],
    value_type=ValueType.STRING,
    description="Loan applicants — POPIA pseudonymized",
    tags={"popia": "data-subject", "governance": "sarb"},
)

loan_facility = Entity(
    name="LoanFacility",
    join_keys=["facility_id"],
    value_type=ValueType.STRING,
    description="Loan facilities and credit products",
    tags={"regulatory": "basel-iii-iv"},
)

credit_bureau_profile = Entity(
    name="CreditBureauProfile",
    join_keys=["applicant_id"],
    value_type=ValueType.STRING,
    description="Credit bureau profiles — NCR compliant",
    tags={"governance": "ncr"},
)

collateral_asset = Entity(
    name="CollateralAsset",
    join_keys=["asset_id"],
    value_type=ValueType.STRING,
    description="Secured lending collateral assets",
)

# ════════════════════════════════════════════════════════════════════════════════
# DATA SOURCES  (parquet files in MinIO written by Spark ETL)
# ════════════════════════════════════════════════════════════════════════════════

source_applicant_risk = SparkSource(
    name="source_applicant_risk_profile",
    path=f"s3a://{BUCKET}/applicant_risk_profile/",
    file_format="parquet",
    timestamp_field="event_timestamp",
    description="MSSQL applicant_profiles + MongoDB application_documents — joined by ETL",
)

source_bureau = SparkSource(
    name="source_bureau_history_aggregated",
    path=f"s3a://{BUCKET}/bureau_history_aggregated/",
    file_format="parquet",
    timestamp_field="event_timestamp",
    description="MySQL bureau_consumer_profiles",
)

source_facility = SparkSource(
    name="source_facility_risk_metrics",
    path=f"s3a://{BUCKET}/facility_risk_metrics/",
    file_format="parquet",
    timestamp_field="event_timestamp",
    description="MSSQL loan_facilities",
)

source_collateral = SparkSource(
    name="source_collateral_valuation_features",
    path=f"s3a://{BUCKET}/collateral_valuation_features/",
    file_format="parquet",
    timestamp_field="event_timestamp",
    description="PostgreSQL collateral_valuations",
)

source_historical = SparkSource(
    name="source_historical_training_features",
    path=f"s3a://{BUCKET}/historical_training_features/",
    file_format="parquet",
    timestamp_field="event_timestamp",
    description="MinIO historical_applications — training labels + macro features",
)

# ════════════════════════════════════════════════════════════════════════════════
# FEATURE VIEWS
# ════════════════════════════════════════════════════════════════════════════════

fv_applicant_risk = FeatureView(
    name="ApplicantRiskProfile",
    entities=[applicant],
    ttl=timedelta(days=1),
    schema=[
        Field(name="age_band",                       dtype=String,  description="Age band, POPIA minimized"),
        Field(name="employment_stability_index",      dtype=Float32, description="Composite employment score 0-1"),
        Field(name="income_quintile",                 dtype=String,  description="Income quintile Q1-Q5"),
        Field(name="existing_exposure_band",          dtype=String,  description="Total credit exposure band"),
        Field(name="payment_to_income_ratio",         dtype=Float32, description="Monthly debt / gross income"),
        Field(name="demographic_risk_score",          dtype=Float32, description="SARB-compliant aggregated risk score"),
        Field(name="income_proof_verification_score", dtype=Float32, description="NLP income doc authenticity 0-1"),
        Field(name="employment_letter_nlp_flag",      dtype=Bool,    description="Employment letter validated"),
        Field(name="document_completeness_score",     dtype=Float32, description="Fraction of required docs submitted"),
    ],
    source=source_applicant_risk,
    tags={"popia": "minimized", "team": "model-risk-management"},
    description="Core applicant risk features — MSSQL + MongoDB joined at ETL",
)

fv_bureau = FeatureView(
    name="BureauHistoryAggregated",
    entities=[credit_bureau_profile],
    ttl=timedelta(days=7),
    schema=[
        Field(name="adverse_listing_flag",  dtype=Bool,   description="Any active adverse listing"),
        Field(name="payment_history_score", dtype=Int64,  description="Payment behaviour score 0-999"),
        Field(name="enquiry_count_90d",     dtype=Int64,  description="Hard enquiries in 90 days"),
        Field(name="accounts_active_count", dtype=Int64,  description="Total open credit accounts"),
        Field(name="worst_status_12m",      dtype=String, description="Worst delinquency status in 12m"),
    ],
    source=source_bureau,
    tags={"governance": "ncr", "team": "credit-risk-data"},
    description="Credit bureau history — NCR compliant aggregation",
)

fv_facility = FeatureView(
    name="FacilityRiskMetrics",
    entities=[loan_facility],
    ttl=timedelta(days=1),
    schema=[
        Field(name="facility_type_encoded", dtype=Int64,  description="HL=0 VAF=1 PL=2 CC=3 OD=4"),
        Field(name="ltv_ratio",             dtype=Float32, description="LTV at origination"),
        Field(name="tenure_months",         dtype=Int64,   description="Months since origination"),
        Field(name="interest_rate_margin",  dtype=Float32, description="Margin above prime"),
        Field(name="expected_loss_band",    dtype=String,  description="IFRS9 stage: Stage1/2/3"),
    ],
    source=source_facility,
    tags={"regulatory": "ifrs9-sarb"},
    description="Loan facility risk parameters — MSSQL loan_facilities",
)

fv_collateral = FeatureView(
    name="CollateralValuationFeatures",
    entities=[collateral_asset],
    ttl=timedelta(days=3),
    schema=[
        Field(name="collateral_type_category",     dtype=String,  description="Property / Vehicle / Equipment"),
        Field(name="valuation_confidence_score",   dtype=Float32, description="AVM confidence 0-1"),
        Field(name="ltv_after_valuation",          dtype=Float32, description="Updated LTV after revaluation"),
        Field(name="insurance_coverage_flag",      dtype=Bool,    description="Active insurance on collateral"),
        Field(name="revaluation_frequency_months", dtype=Int64,   description="Months between revaluations"),
    ],
    source=source_collateral,
    tags={"type": "security", "team": "credit-risk-data"},
    description="Collateral valuation metrics — PostgreSQL collateral_valuations",
)

fv_historical = FeatureView(
    name="HistoricalTrainingFeatures",
    entities=[applicant],
    ttl=timedelta(days=90),
    schema=[
        Field(name="outcome_default_flag",     dtype=Bool,   description="TARGET: 90+dpd in 12m — training only"),
        Field(name="application_year_quarter", dtype=String, description="Vintage e.g. 2024Q1"),
        Field(name="economic_cycle_indicator", dtype=String, description="SARB cycle: Expansion/Peak/Contraction/Trough"),
        Field(name="model_version_used",       dtype=String, description="MLflow run ID"),
        Field(name="demographic_parity_group", dtype=String, description="Fairness audit group — NOT model input"),
    ],
    source=source_historical,
    tags={"purpose": "training-only", "popia": "anonymized"},
    description="Historical outcomes and macro features — offline only",
)

# ════════════════════════════════════════════════════════════════════════════════
# FEATURE SERVICES
# ════════════════════════════════════════════════════════════════════════════════

svc_credit_scoring = FeatureService(
    name="CreditScoringModelTraining",
    features=[fv_applicant_risk, fv_bureau, fv_facility, fv_collateral],
    description="Training features for credit scoring models — fv_1+fv_2+fv_3+fv_4",
    tags={"governance": "sarb-model-risk", "explainability": "shap"},
)

svc_monitoring = FeatureService(
    name="ModelMonitoringAndDrift",
    features=[fv_applicant_risk, fv_facility, fv_historical],
    description="Drift monitoring features — fv_1+fv_3+fv_5",
    tags={"monitoring": "psi-drift", "reporting": "sarb-monthly"},
)

# ── Feature store handle (used when importing directly) ──────────────────────
store = FeatureStore(repo_path=str(REPO_PATH))
