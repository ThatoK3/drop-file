# Credit Risk ML Platform — Feast Feature Store

## Services started by this docker-compose

| Service | Port | URL |
|---|---|---|
| feast-jupyter | 8889 | http://localhost:8889 (token: `feast123`) |
| feast-mlflow | 5000 | http://localhost:5000 |

Both join the existing `spark-jupyter-scala_spark-net` network — no new networks.

## Start

```bash
cp .env.example .env   # fill in your passwords, or defaults will be used
docker compose up -d
```

## File layout

```
feast_credit_risk/
├── docker-compose.yml          # MLflow + Feast Jupyter (port 8889)
├── feature_repo/
│   ├── __init__.py
│   ├── feature_store.yaml      # Feast config — Spark offline, Redis online
│   └── features.py             # Entities, sources, FVs, services — import from notebooks
└── notebooks/
    └── 01_credit_risk_training.ipynb   # Training + online store examples
```

## Import from any notebook

```python
from feature_repo.features import (
    store,
    FEATURE_COLS, CATEGORICAL_COLS, TARGET_COL,
    fv_applicant_risk, fv_bureau, fv_facility, fv_collateral, fv_historical,
    svc_credit_scoring, svc_monitoring,
)
```

## Offline store paths (MinIO)

```
s3a://feast-credit-risk-training/
  applicant_risk_profile/         ← MSSQL + MongoDB joined by Spark ETL
  bureau_history_aggregated/      ← MySQL
  facility_risk_metrics/          ← MSSQL
  collateral_valuation_features/  ← PostgreSQL
  historical_training_features/   ← historical_applications.parquet (re-partitioned)
```

## Online store: Redis

```
healthcare-redis:6379  (password from REDIS_PASSWORD env var)
```

## Notebook walkthrough (01_credit_risk_training.ipynb)

| Cell | What it does |
|---|---|
| 1 | pip installs |
| 2 | imports + config — sets MLFLOW_URI, MINIO creds |
| 3 | `feast apply` — registers entities, FVs, services |
| 4 | load all 5 parquets from MinIO via s3fs |
| 5 | data summary EDA — null rates, default rates, plots |
| 6 | build training dataset — joins + aggregates fv_3/fv_4 to applicant level |
| 7 | feature engineering — encode categoricals, fill nulls |
| 8 | XGBoost training with MLflow — ROC, PR, SHAP, feature importance logged |
| 9 | `feast materialize_incremental` → Redis online store |
| 10 | online store examples — 5 patterns (single, batch, missing, service, E2E score) |
| 11 | load model from MLflow registry + score with IFRS9 staging |
