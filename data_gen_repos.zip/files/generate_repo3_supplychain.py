"""
Repo 3 — supply_chain_demand_forecasting  Synthetic Data Generator
===================================================================
150,000 rows covering all 5 feature views:
  fv_1  ProductDemandProfile       fv_2  NodeOperationalFeatures
  fv_3  SupplierRiskFeatures       fv_4  ForecastAccuracyFeatures
  fv_5  IoTSensorFeatures
"""
import csv, random, os
from datetime import datetime, timedelta

random.seed(42)
N, CHUNK = 150_000, 10_000

def wc(pop,w):
    r=random.uniform(0,sum(w)); c=0
    for item,wi in zip(pop,w):
        c+=wi
        if r<=c: return item
    return pop[-1]
def clamp(v,lo,hi): return max(lo,min(hi,v))
def rn(mean,std,lo,hi,dp=2): return round(clamp(random.gauss(mean,std),lo,hi),dp)

SA_PROVINCES = ["Gauteng","Western Cape","KwaZulu-Natal","Eastern Cape",
                 "Limpopo","Mpumalanga","Free State","North West","Northern Cape"]
PROV_W       = [25,12,15,8,7,6,5,5,2]

CATEGORIES   = ["Food & Beverage","FMCG","Apparel","Electronics","Pharmaceuticals",
                 "Building Materials","Agricultural","Automotive Parts","Healthcare Consumables"]
SKU_PREFIX   = ["SKU","PROD","ART","ITEM"]
VELOCITY_CLASS = ["Fast-Stable","Fast-Variable","Fast-Irregular",
                   "Medium-Stable","Medium-Variable","Medium-Irregular",
                   "Slow-Stable","Slow-Variable","Slow-Irregular"]
TREND_DIR    = ["Strong Growth","Moderate Growth","Stable","Moderate Decline","Strong Decline"]
ELASTICITY   = ["Inelastic","Unit Elastic","Elastic"]
SUPPLIER_TIER= ["Tier1","Tier2","Tier3","Tier4"]
GEO_RISK     = ["Low","Moderate","High","Extreme"]
BIAS_DIR     = ["Consistent Over-forecast","Unbiased","Consistent Under-forecast"]
TEMP_STATUS  = ["Compliant","Warning","Breach","Sensor Fault"]
REVAL_MONTHS = [3,6,12,24,36,60]

FIELDNAMES = [
    "sku_id","node_id","supplier_id","forecast_id","sensor_id",
    "sku_name","category","province","week_date",
    # fv_1 ProductDemandProfile
    "demand_velocity_class","seasonality_strength_index","trend_direction",
    "price_elasticity_band","substitution_risk_score",
    # fv_2 NodeOperationalFeatures
    "current_utilization_rate","capacity_constraint_flag","inbound_lead_time_days",
    "outbound_lead_time_days","seasonal_capacity_factor",
    # fv_3 SupplierRiskFeatures
    "supplier_tier","ontime_delivery_rate","quality_defect_rate",
    "financial_stability_score","geopolitical_risk_band",
    # fv_4 ForecastAccuracyFeatures
    "historical_wape","bias_direction","forecast_revision_count",
    "promotional_lift_factor","external_event_impact",
    # fv_5 IoTSensorFeatures
    "warehouse_temperature_status","equipment_health_score",
    "energy_consumption_anomaly","space_utilization_realtime",
    # extras
    "stockout_flag","average_weekly_units","unit_price_band",
]

output = "/home/claude/supplychain_150k.csv"
print(f"Generating {N:,} rows -> {output}")
written = 0

with open(output,"w",newline="",encoding="utf-8") as fh:
    w = csv.DictWriter(fh,fieldnames=FIELDNAMES); w.writeheader()
    for cs in range(0,N,CHUNK):
        rows=[]
        for i in range(cs, min(cs+CHUNK,N)):
            rn_=i+1
            province = wc(SA_PROVINCES, PROV_W)
            category = random.choice(CATEGORIES)
            days_back = random.randint(7,365*3)
            week_dt   = datetime(2026,3,14)-timedelta(days=days_back)
            week_date = week_dt.strftime("%Y-%W")

            # fv_1
            vel = random.choice(VELOCITY_CLASS)
            fast = vel.startswith("Fast")
            seas = rn(0.31,0.22,0,0.99)
            trend = wc(TREND_DIR,[12,28,38,16,6])
            elast = None if random.random()<0.127 else wc(ELASTICITY,[40,40,20])
            subst = None if random.random()<0.154 else rn(0.24,0.21,0,0.98)

            # fv_2
            util = rn(0.68,0.18,0.01,1.18)
            cap_flag = util>=0.90
            ilt = rn(7.4,5.8,0.5,84)
            olt = rn(1.8,1.2,0.1,28.4)
            seas_cap = rn(1.02,0.12,0.52,1.48)

            # fv_3
            tier = wc(SUPPLIER_TIER,[10,35,40,15])
            otd_base = {"Tier1":0.96,"Tier2":0.90,"Tier3":0.84,"Tier4":0.76}[tier]
            otd = rn(otd_base,0.07,0.12,1.0)
            defect_base = {"Tier1":0.005,"Tier2":0.012,"Tier3":0.020,"Tier4":0.030}[tier]
            defect = rn(defect_base,0.010,0,0.41)
            fin_stab = None if random.random()<0.176 else int(rn(67.2,18.4,4,99,dp=0))
            geo_risk = wc(GEO_RISK,[55,30,12,3])

            # fv_4
            wape_base = 0.20 if fast else 0.45
            wape = rn(wape_base,0.22,0.01,4.82)
            bias = wc(BIAS_DIR,[35,45,20])
            rev_cnt = int(clamp(round(abs(random.gauss(1.8,1.9))),0,18))
            promo = None if random.random()<0.086 else rn(1.24,0.68,0.52,7.84)
            ext_evt = None if random.random()<0.118 else rn(1.04,0.22,0.21,2.94)

            # fv_5 IoT
            cold_chain = category in ("Pharmaceuticals","Food & Beverage")
            if cold_chain:
                temp_status = wc(TEMP_STATUS,[82,10,5,3])
            else:
                temp_status = wc(TEMP_STATUS,[90,6,2,2])
            eq_health = None if random.random()<0.059 else rn(0.76,0.19,0.04,1.0)
            energy_anom = random.random()<0.042
            space_util = None if random.random()<0.082 else rn(0.63,0.17,0.02,0.99)

            stockout = random.random()<0.08
            avg_weekly = int(clamp(round(abs(random.gauss(350,280))),1,9999))
            uprice_band = wc(["<R50","R50-R200","R200-R500","R500-R2k",">R2k"],[20,30,25,18,7])

            rows.append({
                "sku_id": f"{random.choice(SKU_PREFIX)}{rn_:07d}",
                "node_id": f"NODE{random.randint(1,200):03d}",
                "supplier_id": f"SUPP{random.randint(1,500):04d}",
                "forecast_id": f"FC{rn_:08d}",
                "sensor_id": f"SENS{random.randint(1,1000):04d}",
                "sku_name": f"{category[:4].upper()}-{random.randint(10000,99999)}",
                "category": category, "province": province, "week_date": week_date,
                "demand_velocity_class": vel,
                "seasonality_strength_index": seas,
                "trend_direction": trend,
                "price_elasticity_band": elast,
                "substitution_risk_score": subst,
                "current_utilization_rate": util,
                "capacity_constraint_flag": cap_flag,
                "inbound_lead_time_days": ilt,
                "outbound_lead_time_days": olt,
                "seasonal_capacity_factor": seas_cap,
                "supplier_tier": tier,
                "ontime_delivery_rate": otd,
                "quality_defect_rate": defect,
                "financial_stability_score": fin_stab,
                "geopolitical_risk_band": geo_risk,
                "historical_wape": wape,
                "bias_direction": bias,
                "forecast_revision_count": rev_cnt,
                "promotional_lift_factor": promo,
                "external_event_impact": ext_evt,
                "warehouse_temperature_status": temp_status,
                "equipment_health_score": eq_health,
                "energy_consumption_anomaly": energy_anom,
                "space_utilization_realtime": space_util,
                "stockout_flag": stockout,
                "average_weekly_units": avg_weekly,
                "unit_price_band": uprice_band,
            })
        w.writerows(rows); written+=len(rows)
        print(f"  {written:,}/{N:,}")

print(f"\nDone — {written:,} rows | {os.path.getsize(output)/1024/1024:.1f} MB")
