"""
Repo 2 — healthcare_analytics_ml  Synthetic Data Generator
===========================================================
150,000 rows covering all 5 feature views:
  fv_1  PatientRiskProfile          fv_2  EpisodeOutcomeFeatures
  fv_3  ProviderWorkloadFeatures    fv_4  ProtocolAdherenceFeatures
  fv_5  NLPClinicalFeatures
"""
import csv, random, os
from datetime import datetime, timedelta

random.seed(42)
N, CHUNK = 150_000, 10_000

# ── SA Name pools ──────────────────────────────────────────────────────────────
MALE_FIRST   = ["Johannes","Sipho","Thabo","Andile","Kagiso","Lunga","Rajan","David",
                 "Pieter","Bongani","Mduduzi","Katlego","Ahmed","Michael","George"]
FEMALE_FIRST = ["Anna","Nomvula","Thandi","Zanele","Palesa","Lindiwe","Priya","Sarah",
                 "Elizabeth","Bongiwe","Kelebogile","Dineo","Fatima","Jennifer","Nomsa"]
LAST_NAMES   = ["van der Merwe","Dlamini","Nkosi","Mthembu","Molefe","Pillay","Smith",
                 "Botha","Ndlovu","Sithole","Naidoo","Kruger","Zulu","Khumalo","Brown"]
PROVINCES    = ["Gauteng","Western Cape","KwaZulu-Natal","Eastern Cape","Limpopo",
                 "Mpumalanga","Free State","North West","Northern Cape"]
PROV_W       = [25,12,15,8,7,6,5,5,2]

def wc(pop, w):
    r = random.uniform(0, sum(w)); c=0
    for item,wi in zip(pop,w):
        c+=wi
        if r<=c: return item
    return pop[-1]

def clamp(v,lo,hi): return max(lo,min(hi,v))
def rn(mean,std,lo,hi,dp=2): return round(clamp(random.gauss(mean,std),lo,hi),dp)

SPECIALTIES = ["General Practice","Cardiology","Internal Medicine","Emergency",
                "Paediatrics","Oncology","Orthopaedics","Neurology","Psychiatry","ICU"]
DEPARTMENTS  = ["Inpatient Ward","ICU","Emergency","Outpatient","Theatre","Day Ward"]
DISCHARGE_OPTS = ["Home","Home with Services","Rehab","Nursing Facility","Deceased"]
SHIFT_TYPES    = ["Day","Night","Long Day","On-Call","Leave"]
FRAILTY        = ["Robust","Pre-frail","Frail","Severely Frail"]
SOCIAL_SUPPORT = ["Strong","Adequate","Limited","None"]
OUTCOME_ACHIEV = ["Exceeded","Met","Partial","Not Met"]
EXP_BANDS      = ["Junior","Mid","Senior","Expert"]

FIELDNAMES = [
    "patient_hash_id","episode_id","provider_id","protocol_id",
    "first_name","last_name","gender","age","age_band","province",
    # fv_1
    "charlson_comorbidity_index","elixhauser_score","frailty_indicator","social_determinants_score",
    # fv_2
    "length_of_stay_days","drg_weight","icu_flag","discharge_disposition","readmission_30d_risk_score",
    # fv_3
    "provider_experience_band","current_caseload","specialty_demand_index","shift_pattern_type","burnout_risk_indicator",
    # fv_4
    "protocol_adherence_percentage","deviation_count","pathway_completion_flag","expected_outcome_achievement",
    # fv_5
    "sentiment_score","symptom_mention_count","medication_adherence_mention","social_support_indicator",
    # extras
    "admission_date","discharge_date","specialty","department","readmission_within_30d",
]

output = "/home/claude/healthcare_150k.csv"
print(f"Generating {N:,} rows -> {output}")
written = 0

with open(output,"w",newline="",encoding="utf-8") as fh:
    w = csv.DictWriter(fh, fieldnames=FIELDNAMES); w.writeheader()
    for cs in range(0, N, CHUNK):
        rows = []
        for i in range(cs, min(cs+CHUNK,N)):
            rn_ = i+1
            gender = random.choice(["Male","Female"])
            fname  = random.choice(MALE_FIRST if gender=="Male" else FEMALE_FIRST)
            lname  = random.choice(LAST_NAMES)
            age    = int(clamp(round(random.gauss(52,18)),18,95))
            if age<30:   ab="<30"
            elif age<45: ab="30-44"
            elif age<60: ab="45-59"
            elif age<75: ab="60-74"
            else:        ab="75+"
            province = wc(PROVINCES, PROV_W)

            # fv_1 — PatientRiskProfile
            cci = int(clamp(round(abs(random.gauss(2.3,2.8))),0,29))
            elix = int(clamp(round(random.gauss(4.1,5.6)),-6,71))
            frailty = None if random.random()<0.217 else (
                wc(FRAILTY,[50,25,18,7]) if age>60 else wc(FRAILTY,[72,18,8,2]))
            sdh = None if random.random()<0.286 else rn(62.1,18.4,0,100)

            # fv_2 — EpisodeOutcomeFeatures
            icu = random.random()<0.09
            los_base = 8 if icu else 3
            los = int(clamp(round(abs(random.gauss(los_base,5))),0,90))
            drg = rn(1.82,1.34,0.12,22.4)
            if drg is None: drg = None
            else: drg = None if random.random()<0.059 else drg
            disch = random.choice(DISCHARGE_OPTS)
            # readmission risk driven by comorbidity, age, discharge
            ra_base = 0.08 + cci*0.01 + (0.06 if age>70 else 0) + (0.12 if disch=="Home with Services" else 0)
            ra_score = rn(min(ra_base,0.85),0.08,0.01,0.98)
            readmit = int(random.random() < ra_score)

            # fv_3 — ProviderWorkloadFeatures
            exp_band = wc(EXP_BANDS,[25,40,25,10])
            caseload = int(clamp(round(abs(random.gauss(12.4,7.8))),0,72))
            sdi = rn(0.91,0.32,0.08,1.98)
            shift = random.choice(SHIFT_TYPES)
            burnout_base = 0.20 + (0.15 if shift=="Night" else 0) + (caseload/100)
            burnout = None if random.random()<0.158 else rn(burnout_base,0.15,0.01,0.99)

            # fv_4 — ProtocolAdherenceFeatures
            adh_base = 82 - cci*1.2 - (5 if icu else 0)
            adh_pct = rn(adh_base,12,0,100)
            dev_cnt = int(clamp(round(abs(random.gauss(1.4,2.1))),0,38))
            pathway_ok = random.random()<0.71
            outcome_ach = None if random.random()<0.113 else wc(OUTCOME_ACHIEV,[15,45,30,10])

            # fv_5 — NLPClinicalFeatures
            note_avail = random.random()<0.893
            sent_score = rn(0.12,0.34,-0.98,0.99) if note_avail else None
            symptom_cnt = int(rn(8.4,5.9,0,127,dp=0)) if note_avail else 0
            med_adh = (random.random()<0.18) if note_avail else None
            soc_sup = None if (not note_avail or random.random()<0.236) else wc(SOCIAL_SUPPORT,[30,40,22,8])

            # Dates
            days_back = random.randint(30,365*4)
            adm_dt = datetime(2026,3,14) - timedelta(days=days_back)
            dis_dt = adm_dt + timedelta(days=los)
            specialty = random.choice(SPECIALTIES)
            dept = random.choice(DEPARTMENTS)

            rows.append({
                "patient_hash_id": f"PHASH{rn_:08d}",
                "episode_id":      f"EP{rn_:08d}",
                "provider_id":     f"PROV{random.randint(1,500):04d}",
                "protocol_id":     f"PROTO{random.randint(1,80):03d}",
                "first_name": fname, "last_name": lname,
                "gender": gender, "age": age, "age_band": ab, "province": province,
                "charlson_comorbidity_index": cci,
                "elixhauser_score": elix,
                "frailty_indicator": frailty,
                "social_determinants_score": sdh,
                "length_of_stay_days": los,
                "drg_weight": drg,
                "icu_flag": icu,
                "discharge_disposition": disch,
                "readmission_30d_risk_score": ra_score,
                "provider_experience_band": exp_band,
                "current_caseload": caseload,
                "specialty_demand_index": sdi,
                "shift_pattern_type": shift,
                "burnout_risk_indicator": burnout,
                "protocol_adherence_percentage": adh_pct,
                "deviation_count": dev_cnt,
                "pathway_completion_flag": pathway_ok,
                "expected_outcome_achievement": outcome_ach,
                "sentiment_score": sent_score,
                "symptom_mention_count": symptom_cnt,
                "medication_adherence_mention": med_adh,
                "social_support_indicator": soc_sup,
                "admission_date": adm_dt.strftime("%Y-%m-%d"),
                "discharge_date": dis_dt.strftime("%Y-%m-%d"),
                "specialty": specialty, "department": dept,
                "readmission_within_30d": readmit,
            })
        w.writerows(rows); written+=len(rows)
        print(f"  {written:,}/{N:,}")

print(f"\nDone — {written:,} rows | {os.path.getsize(output)/1024/1024:.1f} MB")
print(f"  ICU rate: {sum(1 for r in open(output) if ',True,' in r)/N:.1%}")
