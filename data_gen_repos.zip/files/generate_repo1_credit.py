"""
Credit Risk ML Platform — Synthetic Data Generator
====================================================
Generates 150,000 rows of realistic South-African credit-risk data
aligned with the FeastArchitect JSON repo schema.

Features generated per feature-view:
  fv_1  ApplicantRiskProfile        → age_band, employment_stability_index,
                                       income_quintile, existing_exposure_band,
                                       payment_to_income_ratio, demographic_risk_score
  fv_2  BureauHistoryAggregated     → adverse_listing_flag, payment_history_score,
                                       enquiry_count_90d, accounts_active_count,
                                       worst_status_12m
  fv_3  FacilityRiskMetrics         → facility_type_encoded, ltv_ratio, tenure_months,
                                       interest_rate_margin, expected_loss_band
  fv_4  CollateralValuationFeatures → collateral_type_category, valuation_confidence_score,
                                       ltv_after_valuation, insurance_coverage_flag,
                                       revaluation_frequency_months
  fv_5  HistoricalTrainingFeatures  → outcome_default_flag, application_year_quarter,
                                       economic_cycle_indicator, model_version_used,
                                       demographic_parity_group

Names use gender-correct South-African pools (Afrikaans, Zulu, Sotho,
Xhosa, Venda, Indian, Cape Malay, English). No Faker dependency required.

Output: credit_risk_150k.csv
"""

import csv
import random
import os
from datetime import datetime, timedelta

# ── Reproducibility ────────────────────────────────────────────────────────────
random.seed(42)

N      = 150_000
CHUNK  = 10_000

# ── Gender-correct South African name pools ─────────────────────────────────
MALE_FIRST = [
    # Afrikaans / Cape Dutch
    "Johannes","Pieter","Jacobus","Willem","Andries","Hendrik","Gabriel",
    "Christiaan","Frederik","Cornelius","Adriaan","Barend","Danie","Frikkie","Jan",
    # Zulu / Nguni
    "Sipho","Thabo","Siyabonga","Lungelo","Nhlanhla","Mthokozisi","Bongani",
    "Sandile","Sifiso","Lwazi","Mduduzi","Zwelakhe","Sibonelo","Mxolisi","Sibusiso",
    # Sotho / Tswana
    "Kgomotso","Kagiso","Tshepo","Katlego","Lefa","Mpho","Tebogo","Lesedi",
    "Refilwe","Lerato","Nthabiseng","Dineo","Tumelo",
    # Xhosa
    "Andile","Lunga","Mthobeli","Xolani","Mzwandile","Lungisa","Ayanda",
    # Venda / Tsonga
    "Thivhilaheli","Mulalo","Rudzani","Tshilidzi","Pfano",
    # Indian / Cape Malay
    "Rajan","Pradeep","Ashwin","Imran","Farouk","Yusuf","Ahmed","Tariq",
    # English
    "David","Michael","James","Robert","Andrew","Mark","Paul",
    "George","Richard","John","Thomas","Stephen","Kevin",
]

FEMALE_FIRST = [
    # Afrikaans
    "Anna","Elizabeth","Maria","Johanna","Magdalena","Susanna","Catharina",
    "Helena","Sophia","Petronella","Aletta","Francina","Hester","Madelief","Elmarie",
    # Zulu / Nguni
    "Nomvula","Thandi","Zanele","Nompumelelo","Siphokazi","Lindiwe",
    "Nokuthula","Nontobeko","Ntombi","Bongiwe","Nokukhanya","Lungile","Nozipho",
    # Sotho / Tswana
    "Lerato","Dineo","Kelebogile","Tshepiso","Palesa","Boitumelo",
    "Puleng","Tebogo","Mmapula","Nthabi","Katlego","Neo","Refilwe",
    # Xhosa
    "Nomsa","Nozipho","Busisiwe","Nokwanda","Nolwandle","Siyanda",
    # Venda / Tsonga
    "Pfanani","Tshifhiwa","Vhuhwavho","Mulalo","Masindi",
    # Indian / Cape Malay
    "Priya","Sarika","Fatima","Aisha","Nadia","Zahra","Yasmin","Tasneem",
    # English
    "Sarah","Jennifer","Michelle","Karen","Sharon","Tracey",
    "Natalie","Lauren","Catherine","Patricia","Lisa","Deborah",
]

LAST_NAMES = [
    # Afrikaans
    "van der Merwe","Botha","du Plessis","van Niekerk","Joubert","Cronje",
    "Steyn","Viljoen","Kruger","Coetzee","Pretorius","du Toit","Marais",
    "van Zyl","Swanepoel","Burger","Nortje","Louw","Nel","Botes","de Wet",
    # Zulu / Nguni
    "Dlamini","Nkosi","Mthembu","Ndlovu","Zulu","Khumalo","Ngcobo",
    "Mhlongo","Cele","Ngubane","Ntuli","Mkhize","Nzama","Majola","Buthelezi",
    # Sotho / Tswana
    "Molefe","Motsepe","Sithole","Nkuna","Sefoka","Mokoena",
    "Mashaba","Kgosana","Segoe","Moroka","Tladi","Mahlangu",
    # Xhosa
    "Mfengu","Xaba","Tywakadi","Maqagi","Jikelo",
    # Indian
    "Pillay","Naidoo","Reddy","Govender","Moodley","Chetty","Naicker",
    # Cape Malay / Coloured
    "Davids","Jansen","Adams","Williams","October","September","Hendricks",
    # English
    "Smith","Johnson","Brown","Jones","Taylor","Wilson","Moore",
]

# ── Geography ──────────────────────────────────────────────────────────────────
PROVINCES = [
    "Eastern Cape","Free State","Gauteng","KwaZulu-Natal",
    "Limpopo","Mpumalanga","Northern Cape","North West","Western Cape",
]
PROVINCE_WEIGHTS = [8, 5, 25, 15, 7, 6, 2, 5, 12]

CITIES = {
    "Eastern Cape":  ["Port Elizabeth","East London","Mthatha","Queenstown","Bhisho"],
    "Free State":    ["Bloemfontein","Welkom","Kroonstad","Sasolburg","Phuthaditjhaba"],
    "Gauteng":       ["Johannesburg","Pretoria","Soweto","Randburg","Sandton",
                      "Centurion","Midrand","Kempton Park"],
    "KwaZulu-Natal": ["Durban","Pietermaritzburg","Newcastle","Richards Bay",
                      "Ulundi","Empangeni"],
    "Limpopo":       ["Polokwane","Thohoyandou","Tzaneen","Mokopane","Louis Trichardt"],
    "Mpumalanga":    ["Nelspruit","Witbank","Middelburg","Ermelo","Barberton"],
    "Northern Cape": ["Kimberley","Upington","Springbok","Kuruman","De Aar"],
    "North West":    ["Rustenburg","Potchefstroom","Klerksdorp","Mahikeng","Lichtenburg"],
    "Western Cape":  ["Cape Town","Stellenbosch","George","Paarl","Worcester","Bellville"],
}

# ── Lookup tables ──────────────────────────────────────────────────────────────
FACILITY_TYPES  = {0:"Home Loan",1:"Vehicle Finance",2:"Personal Loan",
                   3:"Credit Card",4:"Overdraft"}
FACILITY_W      = [20, 22, 30, 18, 10]

COLLATERAL_TYPES = [
    "Residential Property","Commercial Property","Vehicle","Equipment",None
]

ECONOMIC_CYCLES = ["Expansion","Peak","Contraction","Trough"]
ECONOMIC_W      = [30, 15, 35, 20]

MLFLOW_RUNS = [
    "run_a1b2c3d4","run_e5f6g7h8","run_i9j0k1l2","run_m3n4o5p6",
    "run_q7r8s9t0","run_u1v2w3x4","run_y5z6a7b8","run_c9d0e1f2",
]

QUARTERS = [f"{yr}Q{q}" for yr in range(2020,2026) for q in range(1,5)][:24]

# ── Helpers ────────────────────────────────────────────────────────────────────
def weighted_choice(pop, weights):
    r = random.uniform(0, sum(weights))
    c = 0
    for item, w in zip(pop, weights):
        c += w
        if r <= c:
            return item
    return pop[-1]

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def rand_norm(mean, std, lo, hi, dp=2):
    return round(clamp(random.gauss(mean, std), lo, hi), dp)

def random_age():
    r = random.random()
    if r < 0.05:   return random.randint(18, 22)
    elif r < 0.80: return random.randint(23, 60)
    elif r < 0.97: return random.randint(61, 75)
    else:          return random.randint(76, 85)

def compute_pd(age, ph_score, adverse, pti, income_q, exp_band, enquiries, worst_st):
    """Calibrated PD approximation targeting ~8.7% mean default rate."""
    base = 0.040  # calibrated to ~8.7% overall default rate
    if age < 25:   base += 0.02
    elif age > 65: base += 0.01
    if ph_score is not None:
        base -= (ph_score - 500) / 12000.0
    if adverse: base += 0.12   # was 0.20
    base += max(0, (pti - 0.40) * 0.20)
    if income_q in ("Q1","Q2"): base += 0.02
    if exp_band == "Very High":  base += 0.03
    if enquiries >= 5:           base += 0.02
    ws_boost = {"0":0,"1":0.02,"2":0.05,"3":0.10,"4":0.20}
    base += ws_boost.get(str(worst_st), 0)
    base += random.gauss(0, 0.010)
    return clamp(base, 0.001, 0.95)

# ── Output columns ─────────────────────────────────────────────────────────────
FIELDNAMES = [
    # Entity hash keys
    "applicant_hash_id","facility_hash_id","bureau_profile_hash","collateral_hash_id",
    # Applicant / fv_1
    "first_name","last_name","gender","age","age_band",
    "province","city","postal_code",
    "income_quintile","employment_stability_index","existing_exposure_band",
    "payment_to_income_ratio","demographic_risk_score","demographic_parity_group",
    # Bureau / fv_2
    "adverse_listing_flag","payment_history_score","enquiry_count_90d",
    "accounts_active_count","worst_status_12m",
    # Facility / fv_3
    "facility_type","facility_type_encoded","ltv_ratio","tenure_months",
    "interest_rate_margin","expected_loss_band",
    # Collateral / fv_4
    "collateral_type_category","valuation_confidence_score","ltv_after_valuation",
    "insurance_coverage_flag","revaluation_frequency_months",
    # Training labels / fv_5
    "outcome_default_flag","application_year_quarter",
    "economic_cycle_indicator","model_version_used",
    # Extra analyst metadata
    "loan_amount_band","interest_rate_pct","monthly_installment_band",
    "application_date","origination_date",
]

# ── Main ───────────────────────────────────────────────────────────────────────
output_path = "/home/claude/credit_risk_150k.csv"
print(f"Generating {N:,} rows -> {output_path}")
written = 0

with open(output_path, "w", newline="", encoding="utf-8") as fh:
    writer = csv.DictWriter(fh, fieldnames=FIELDNAMES)
    writer.writeheader()

    for chunk_start in range(0, N, CHUNK):
        chunk_rows = []
        chunk_end  = min(chunk_start + CHUNK, N)

        for i in range(chunk_start, chunk_end):
            rn = i + 1  # 1-based record number

            # ── Demographics ─────────────────────────────────────────────
            gender = random.choice(["Male","Female"])
            first_name = random.choice(MALE_FIRST if gender == "Male" else FEMALE_FIRST)
            last_name  = random.choice(LAST_NAMES)
            age        = random_age()

            if age < 25:   age_band = "18-24"
            elif age < 35: age_band = "25-34"
            elif age < 50: age_band = "35-49"
            else:          age_band = "50+"

            province    = weighted_choice(PROVINCES, PROVINCE_WEIGHTS)
            city        = random.choice(CITIES[province])
            postal_code = str(random.randint(1000, 9999))

            # ── Income / employment (fv_1) ────────────────────────────────
            iq_num = int(clamp(round(random.gauss(3.0, 1.2)), 1, 5))
            income_quintile = f"Q{iq_num}"

            emp_base = 0.50 + (iq_num - 1) * 0.08
            if age < 28: emp_base -= 0.10
            if age > 55: emp_base -= 0.05
            emp_stability = rand_norm(emp_base, 0.20, 0.0, 1.0)

            if iq_num >= 4:
                exp_w = [30, 35, 25, 10]
            else:
                exp_w = [45, 30, 18, 7]
            existing_exposure_band = weighted_choice(
                ["Low","Medium","High","Very High"], exp_w)

            pti_base = {"Q1":0.48,"Q2":0.42,"Q3":0.34,"Q4":0.27,"Q5":0.20}[income_quintile]
            pti_ratio = rand_norm(pti_base, 0.12, 0.0, 1.48)

            base_score = 600 - pti_ratio*200 + emp_stability*150 + (iq_num-1)*30
            if existing_exposure_band == "Very High": base_score -= 80
            elif existing_exposure_band == "High":    base_score -= 40
            demo_risk_score = int(rand_norm(base_score, 80, 12, 998, dp=0))

            # Demographic parity group (6 groups, ~8.6% null)
            prov_cluster = {
                "Gauteng":"Urban","Western Cape":"Urban",
                "KwaZulu-Natal":"Coastal","Eastern Cape":"Coastal",
                "Free State":"Inland","Mpumalanga":"Inland",
                "Limpopo":"Rural","North West":"Rural","Northern Cape":"Rural",
            }[province]
            g_key = f"{age_band}_{prov_cluster}"
            group_map = {
                "18-24_Urban":"G1","25-34_Urban":"G2","35-49_Urban":"G2","50+_Urban":"G3",
                "18-24_Coastal":"G1","25-34_Coastal":"G2","35-49_Coastal":"G2","50+_Coastal":"G3",
                "18-24_Inland":"G4","25-34_Inland":"G4","35-49_Inland":"G5","50+_Inland":"G5",
                "18-24_Rural":"G4","25-34_Rural":"G4","35-49_Rural":"G6","50+_Rural":"G6",
            }
            demo_parity = group_map.get(g_key,"G4") if random.random() > 0.086 else None

            # ── Bureau (fv_2) ─────────────────────────────────────────────
            adverse_base = 0.06
            if income_quintile in ("Q1","Q2"):           adverse_base += 0.10
            if existing_exposure_band == "Very High":    adverse_base += 0.08
            adverse_flag = random.random() < adverse_base

            ph_base = 700 - (150 if adverse_flag else 0) + (iq_num-1)*20
            payment_history_score = (
                None if random.random() < 0.026
                else int(rand_norm(ph_base, 130, 0, 999, dp=0))
            )

            enquiry_count = int(clamp(round(random.expovariate(1/2.1)), 0, 47))
            accounts_active = int(clamp(round(abs(random.gauss(4.3, 3.1))), 0, 67))

            if adverse_flag:
                ws_w = [10, 15, 20, 25, 30]
            elif payment_history_score and payment_history_score > 750:
                ws_w = [75, 12, 8,  3,   2]
            else:
                ws_w = [55, 20, 12, 8,   5]
            worst_status = (
                None if random.random() < 0.022
                else str(weighted_choice([0,1,2,3,4], ws_w))
            )

            # ── Facility (fv_3) ────────────────────────────────────────────
            ft_enc   = weighted_choice(list(FACILITY_TYPES.keys()), FACILITY_W)
            ft_label = FACILITY_TYPES[ft_enc]

            tenure = int(clamp(round(abs(random.gauss(28.4, 22.1))), 0, 348))

            if ft_label in ("Personal Loan","Credit Card","Overdraft"):
                ltv_ratio = None
            else:
                ltv_ratio = rand_norm(0.71, 0.22, 0.0, 1.95)

            im_base = 3.2 - (demo_risk_score - 512) / 300.0
            ir_margin = rand_norm(im_base, 2.1, -1.5, 14.8)
            ir_pct    = round(11.75 + ir_margin, 2)

            if ft_label == "Home Loan":
                loan_band = random.choice(["R200k-R500k","R500k-R1m","R1m-R2m","R2m-R5m"])
            elif ft_label == "Vehicle Finance":
                loan_band = random.choice(["R50k-R100k","R100k-R250k","R250k-R500k"])
            elif ft_label == "Personal Loan":
                loan_band = random.choice(["<R10k","R10k-R50k","R50k-R150k","R150k-R350k"])
            elif ft_label == "Credit Card":
                loan_band = random.choice(["<R10k","R10k-R50k","R50k-R150k"])
            else:
                loan_band = random.choice(["<R10k","R10k-R50k"])

            monthly_band = random.choice([
                "<R1k","R1k-R3k","R3k-R7k","R7k-R15k","R15k-R30k",">R30k"])

            pd_val = compute_pd(
                age, payment_history_score or 500,
                adverse_flag, pti_ratio, income_quintile,
                existing_exposure_band, enquiry_count, worst_status or "0"
            )
            if pd_val < 0.005:   el_band = "Stage1"
            elif pd_val < 0.05:  el_band = "Stage2"
            else:                el_band = "Stage3"

            # ── Collateral (fv_4) ──────────────────────────────────────────
            if ft_label == "Home Loan":
                cw = [65, 10, 5, 2, 18]
            elif ft_label == "Vehicle Finance":
                cw = [5,  2, 80, 5,  8]
            elif ft_label == "Personal Loan":
                cw = [5,  2,  5, 5, 83]
            else:
                cw = [10, 3, 10, 8, 69]
            coll_type = weighted_choice(COLLATERAL_TYPES, cw)

            if coll_type is None:
                val_conf     = None
                ltv_after    = None
                reval_freq   = None
                insured      = False
            else:
                val_conf   = rand_norm(0.74, 0.18, 0.10, 0.99)
                ltv_after  = rand_norm(0.68, 0.24, 0.0,  2.87)
                reval_freq = random.choice([3, 6, 12, 24, 36, 60])
                insured    = random.random() < 0.78

            # ── Training labels (fv_5) ─────────────────────────────────────
            outcome_default = int(random.random() < pd_val)

            days_back = random.randint(30, 365*6)
            app_dt    = datetime(2026, 3, 14) - timedelta(days=days_back)
            app_date  = app_dt.strftime("%Y-%m-%d")
            orig_dt   = app_dt + timedelta(days=random.randint(0, 30))
            orig_date = orig_dt.strftime("%Y-%m-%d")

            q_raw = f"{app_dt.year}Q{(app_dt.month-1)//3+1}"
            app_yq = q_raw if q_raw in QUARTERS else random.choice(QUARTERS)

            econ_cycle = weighted_choice(ECONOMIC_CYCLES, ECONOMIC_W)
            mlflow_run = (
                None if random.random() < 0.018
                else random.choice(MLFLOW_RUNS)
            )

            # ── Hash entity keys ───────────────────────────────────────────
            row = {
                "applicant_hash_id":           f"AHASH{rn:08d}",
                "facility_hash_id":            f"FHASH{rn:08d}",
                "bureau_profile_hash":         f"BHASH{rn:08d}",
                "collateral_hash_id":          f"CHASH{rn:08d}" if coll_type else None,
                "first_name":                  first_name,
                "last_name":                   last_name,
                "gender":                      gender,
                "age":                         age,
                "age_band":                    age_band,
                "province":                    province,
                "city":                        city,
                "postal_code":                 postal_code,
                "income_quintile":             income_quintile,
                "employment_stability_index":  emp_stability,
                "existing_exposure_band":      existing_exposure_band,
                "payment_to_income_ratio":     pti_ratio,
                "demographic_risk_score":      demo_risk_score,
                "demographic_parity_group":    demo_parity,
                "adverse_listing_flag":        adverse_flag,
                "payment_history_score":       payment_history_score,
                "enquiry_count_90d":           enquiry_count,
                "accounts_active_count":       accounts_active,
                "worst_status_12m":            worst_status,
                "facility_type":               ft_label,
                "facility_type_encoded":       ft_enc,
                "ltv_ratio":                   ltv_ratio,
                "tenure_months":               tenure,
                "interest_rate_margin":        ir_margin,
                "expected_loss_band":          el_band,
                "collateral_type_category":    coll_type,
                "valuation_confidence_score":  val_conf,
                "ltv_after_valuation":         ltv_after,
                "insurance_coverage_flag":     insured,
                "revaluation_frequency_months": reval_freq,
                "outcome_default_flag":        outcome_default,
                "application_year_quarter":    app_yq,
                "economic_cycle_indicator":    econ_cycle,
                "model_version_used":          mlflow_run,
                "loan_amount_band":            loan_band,
                "interest_rate_pct":           ir_pct,
                "monthly_installment_band":    monthly_band,
                "application_date":            app_date,
                "origination_date":            orig_date,
            }
            chunk_rows.append(row)

        writer.writerows(chunk_rows)
        written += len(chunk_rows)
        print(f"  {written:,} / {N:,} rows ({100*written//N}%)")

print(f"\nDone — {written:,} rows written to {output_path}")

# ── QA summary ─────────────────────────────────────────────────────────────────
print("\nQA check ...")
with open(output_path, newline="", encoding="utf-8") as fh:
    rows = list(csv.DictReader(fh))

total    = len(rows)
defaults = sum(1 for r in rows if r["outcome_default_flag"] == "1")
adverse  = sum(1 for r in rows if r["adverse_listing_flag"] == "True")
male     = sum(1 for r in rows if r["gender"] == "Male")
stage3   = sum(1 for r in rows if r["expected_loss_band"] == "Stage3")
secured  = sum(1 for r in rows if r["collateral_type_category"] not in ("","None"))
sz_mb    = os.path.getsize(output_path) / 1024 / 1024

print(f"  Rows                  : {total:,}")
print(f"  Default rate          : {defaults/total:.2%}  (target ~8.7%)")
print(f"  Adverse listing rate  : {adverse/total:.2%}   (target ~12%)")
print(f"  Gender split M/F      : {male/total:.1%} / {(total-male)/total:.1%}")
print(f"  IFRS9 Stage 3         : {stage3/total:.2%}")
print(f"  Secured facilities    : {secured/total:.1%}")
print(f"  File size             : {sz_mb:.1f} MB")
