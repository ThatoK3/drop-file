"""
Repo 4 — insurance_pricing_ml_platform  Synthetic Data Generator
=================================================================
150,000 rows covering all 5 feature views:
  fv_1  PolicyholderRiskProfile       fv_2  ClaimsExperienceFeatures
  fv_3  PolicyCoverageFeatures        fv_4  ActuarialSegmentationFeatures
  fv_5  CatastropheRiskFeatures
"""
import csv, random, os
from datetime import datetime, timedelta

random.seed(42)
N, CHUNK = 150_000, 10_000

MALE_FIRST   = ["Johannes","Sipho","Thabo","Pieter","Kagiso","David","Rajan","Ahmed",
                 "Andile","Michael","Bongani","Katlego","Lunga","George","Willem"]
FEMALE_FIRST = ["Anna","Nomvula","Thandi","Zanele","Palesa","Elizabeth","Priya","Fatima",
                 "Lindiwe","Sarah","Bongiwe","Dineo","Kelebogile","Jennifer","Maria"]
LAST_NAMES   = ["van der Merwe","Dlamini","Nkosi","Botha","Molefe","Pillay","Smith",
                 "Ndlovu","Sithole","Naidoo","Kruger","Zulu","Khumalo","Brown","Mthembu"]

def wc(pop,w):
    r=random.uniform(0,sum(w)); c=0
    for item,wi in zip(pop,w):
        c+=wi
        if r<=c: return item
    return pop[-1]
def clamp(v,lo,hi): return max(lo,min(hi,v))
def rn(mean,std,lo,hi,dp=2): return round(clamp(random.gauss(mean,std),lo,hi),dp)

PROVINCES   = ["Gauteng","Western Cape","KwaZulu-Natal","Eastern Cape","Limpopo",
                "Mpumalanga","Free State","North West","Northern Cape"]
PROV_W      = [25,12,15,8,7,6,5,5,2]
AGE_BANDS   = ["18-24","25-34","35-44","45-54","55-64","65+"]
GENDER_FACTORS = ["Male","Female","Non-binary"]
SMOKING     = ["Non-Smoker","Ex-Smoker (<5yr)","Ex-Smoker (5yr+)","Current Smoker"]
OCC_CLASS   = ["Class1","Class2","Class3","Class4"]
INC_STAB    = ["Very Stable","Stable","Variable","Irregular"]
GEO_ZONES   = ["A","B","C","D","E"]
CLAIM_COST_BANDS = ["<R5k","R5k-R25k","R25k-R100k","R100k-R500k",">R500k"]
CLAIM_CAUSE = ["Accident","Illness","Theft","Weather","Fire","Third-Party","Other"]
NCB_LEVELS  = ["NCB0","NCB1","NCB2","NCB3","NCB4","NCB5"]
PRODUCTS    = ["Term Life","Whole Life","Endowment","Disability","Critical Illness",
               "Short-Term Property","Short-Term Vehicle"]
PROD_W      = [20,10,8,12,10,22,18]
SUM_ASSURED = ["<R100k","R100k-R500k","R500k-R1m","R1m-R5m",">R5m"]
PAY_TERMS   = ["Monthly","Quarterly","Annual","Single Premium","Limited Pay (10yr)","Limited Pay (20yr)"]
WAIT_STATUS = ["Pre-waiting","Active Waiting","Waiting Complete","Waiver Applied"]
BASE_SEGS   = [f"S{i}" for i in range(1,13)]
FLOOD_ZONES = ["No Risk","Low","Moderate","High","Extreme"]
WIND_BANDS  = ["Low","Moderate","High","Severe"]
WEATHER_FREQ= ["Rare","Occasional","Frequent"]

FIELDNAMES = [
    "policy_hash_id","policyholder_id","claim_ref","collateral_hash_id",
    "first_name","last_name","gender","age","age_band","province","postal_code",
    # fv_1
    "gender_pricing_factor","smoking_status","occupation_risk_class",
    "income_stability_band","geographic_risk_zone",
    # fv_2
    "claim_frequency_3yr","average_claim_cost_band","claim_cause_category",
    "time_since_last_claim_months","no_claims_bonus_level",
    # fv_3
    "product_type","sum_assured_band","premium_payment_term",
    "waiting_period_status","rider_benefits_count",
    # fv_4
    "base_rate_segment","risk_adjustment_factor","lapse_rate_expectation",
    "expense_loading_percentage","profit_margin_target",
    # fv_5
    "flood_risk_zone","earthquake_risk_score","windstorm_exposure_band",
    "crime_risk_index","weather_event_frequency",
    # extras
    "inception_date","policy_active_flag","annual_premium_band","lapse_within_1yr",
]

output = "/home/claude/insurance_150k.csv"
print(f"Generating {N:,} rows -> {output}")
written = 0

with open(output,"w",newline="",encoding="utf-8") as fh:
    wr = csv.DictWriter(fh,fieldnames=FIELDNAMES); wr.writeheader()
    for cs in range(0,N,CHUNK):
        rows=[]
        for i in range(cs,min(cs+CHUNK,N)):
            rn_=i+1
            gender = random.choice(["Male","Female","Non-binary"])
            fname  = random.choice(MALE_FIRST if gender=="Male" else FEMALE_FIRST)
            lname  = random.choice(LAST_NAMES)
            # age distribution skewed toward working age
            age = int(clamp(round(random.gauss(42,14)),18,85))
            if age<25:   ab="18-24"
            elif age<35: ab="25-34"
            elif age<45: ab="35-44"
            elif age<55: ab="45-54"
            elif age<65: ab="55-64"
            else:        ab="65+"
            province = wc(PROVINCES,PROV_W)
            postal_code = str(random.randint(1000,9999))

            # fv_1
            gpf = wc(["Male","Female","Non-binary"],[45,52,3])
            smoke = wc(SMOKING,[60,8,12,20])
            occ = wc(OCC_CLASS,[40,35,18,7])
            inc_stab = None if random.random()<0.069 else wc(INC_STAB,[25,40,25,10])
            geo_zone = wc(GEO_ZONES,[15,28,32,18,7])

            # fv_2 — claims history (15.8% no claims at all)
            no_claim_hist = random.random()<0.158
            if no_claim_hist:
                claim_freq = 0.0
                claim_cost_band = None
                claim_cause = None
                tslc = None
                ncb = "NCB" + str(min(5, random.randint(3,7)))
            else:
                claim_freq = rn(0.42,0.68,0,18.3)
                claim_cost_band = wc(CLAIM_COST_BANDS,[30,35,22,10,3])
                claim_cause = random.choice(CLAIM_CAUSE)
                tslc = int(rn(38.4,31.2,0,312,dp=0))
                ncb_yrs = max(0, int(tslc/12) - 1) if tslc else 0
                ncb = f"NCB{min(5,ncb_yrs)}"

            # fv_3
            product = wc(PRODUCTS,PROD_W)
            sa_band = wc(SUM_ASSURED,[12,35,28,20,5])
            pay_term = wc(PAY_TERMS,[45,8,25,5,9,8])
            wait_stat = wc(WAIT_STATUS,[5,10,80,5])
            riders = int(rn(1.4,1.2,0,9,dp=0))

            # fv_4
            seg_idx = (AGE_BANDS.index(ab) * 2 + OCC_CLASS.index(occ) % 2) % 12
            base_seg = BASE_SEGS[seg_idx]
            smoke_load = 1.4 if smoke=="Current Smoker" else 1.1 if "Ex-Smoker" in smoke else 1.0
            occ_load = {"Class1":0.95,"Class2":1.0,"Class3":1.15,"Class4":1.40}[occ]
            raf = rn(smoke_load*occ_load,0.15,0.51,2.98)
            lapse_base = 0.08 + (0.05 if no_claim_hist else 0) + (0.04 if pay_term=="Monthly" else 0)
            lapse_exp = rn(lapse_base,0.07,0.01,0.92)
            exp_load = rn(0.187,0.062,0.04,0.48)
            profit_tgt = rn(0.082,0.041,-0.08,0.38)

            # fv_5 cat risk
            flood_zone = wc(FLOOD_ZONES,[25,32,24,13,6])
            eq_score = rn(1.8,1.6,0,9.4)
            wind_band = wc(WIND_BANDS,[35,38,20,7])
            crime_idx = rn(42.3,24.1,0.8,99.4)
            weather_freq = wc(WEATHER_FREQ,[45,38,17])

            # Dates & extras
            days_back = random.randint(30,365*8)
            incep_dt = datetime(2026,3,14)-timedelta(days=days_back)
            active = random.random()>0.12
            premium_band = wc(["<R2k","R2k-R6k","R6k-R15k","R15k-R40k",">R40k"],[15,30,30,18,7])
            lapse_1yr = int(random.random()<lapse_exp*0.6)

            rows.append({
                "policy_hash_id": f"POLH{rn_:08d}",
                "policyholder_id": f"PHD{rn_:08d}",
                "claim_ref": f"CLM{random.randint(100000,999999)}",
                "collateral_hash_id": f"CHASH{rn_:08d}",
                "first_name":fname,"last_name":lname,
                "gender":gender,"age":age,"age_band":ab,
                "province":province,"postal_code":postal_code,
                "gender_pricing_factor":gpf,"smoking_status":smoke,
                "occupation_risk_class":occ,"income_stability_band":inc_stab,
                "geographic_risk_zone":geo_zone,
                "claim_frequency_3yr":claim_freq,"average_claim_cost_band":claim_cost_band,
                "claim_cause_category":claim_cause,"time_since_last_claim_months":tslc,
                "no_claims_bonus_level":ncb,
                "product_type":product,"sum_assured_band":sa_band,
                "premium_payment_term":pay_term,"waiting_period_status":wait_stat,
                "rider_benefits_count":riders,
                "base_rate_segment":base_seg,"risk_adjustment_factor":raf,
                "lapse_rate_expectation":lapse_exp,"expense_loading_percentage":exp_load,
                "profit_margin_target":profit_tgt,
                "flood_risk_zone":flood_zone,"earthquake_risk_score":eq_score,
                "windstorm_exposure_band":wind_band,"crime_risk_index":crime_idx,
                "weather_event_frequency":weather_freq,
                "inception_date":incep_dt.strftime("%Y-%m-%d"),
                "policy_active_flag":active,"annual_premium_band":premium_band,
                "lapse_within_1yr":lapse_1yr,
            })
        wr.writerows(rows); written+=len(rows)
        print(f"  {written:,}/{N:,}")

print(f"\nDone — {written:,} rows | {os.path.getsize(output)/1024/1024:.1f} MB")
