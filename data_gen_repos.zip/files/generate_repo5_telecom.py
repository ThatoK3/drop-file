"""
Repo 5 — telecom_customer_churn_ml  Synthetic Data Generator
=============================================================
150,000 rows covering all 5 feature views:
  fv_1  SubscriberLifecycleFeatures   fv_2  BillingBehaviourFeatures
  fv_3  NetworkExperienceFeatures     fv_4  ProductEngagementFeatures
  fv_5  InteractionSentimentFeatures
"""
import csv, random, os
from datetime import datetime, timedelta

random.seed(42)
N, CHUNK = 150_000, 10_000

MALE_FIRST   = ["Johannes","Sipho","Thabo","Pieter","Kagiso","David","Rajan","Ahmed",
                 "Andile","Michael","Bongani","Katlego","Lunga","George","Willem"]
FEMALE_FIRST = ["Anna","Nomvula","Thandi","Zanele","Palesa","Elizabeth","Priya","Fatima",
                 "Lindiwe","Sarah","Bongiwe","Dineo","Kelebogile","Jennifer","Maria"]
LAST_NAMES   = ["van der Merwe","Dlamini","Nkosi","Botha","Molefe","Pillay","Smith",
                 "Ndlovu","Sithole","Naidoo","Kruger","Zulu","Khumalo","Brown","Mthembu"]

def wc(pop,w):
    r=random.uniform(0,sum(w)); c=0
    for item,wi in zip(pop,w):
        c+=wi
        if r<=c: return item
    return pop[-1]
def clamp(v,lo,hi): return max(lo,min(hi,v))
def rn(mean,std,lo,hi,dp=2): return round(clamp(random.gauss(mean,std),lo,hi),dp)

PROVINCES = ["Gauteng","Western Cape","KwaZulu-Natal","Eastern Cape","Limpopo",
              "Mpumalanga","Free State","North West","Northern Cape"]
PROV_W    = [25,12,15,8,7,6,5,5,2]

CONTRACT_TYPES   = ["Month-to-Month","12-Month","24-Month","Prepaid","Corporate","IoT"]
CONTRACT_W       = [28,18,18,25,8,3]
PAY_STAB         = ["Stable","One Change","Frequent Changes","Lapsed"]
CLV_BANDS        = ["Dormant","Low","Mid","High","Premium"]
CLV_W            = [8,25,35,22,10]
ARPU_BANDS       = ["<R100","R100-R300","R300-R700","R700-R1500",">R1500"]
ARPU_W           = [12,28,35,18,7]
PAY_METH_CHANGE  = ["None","Low","Moderate","High"]
ARPU_TREND       = ["Strong Growth","Moderate Growth","Stable","Moderate Decline","Strong Decline"]
DATA_SPEED       = ["Excellent","Good","Fair","Poor"]
DATA_SPEED_W     = [28,38,22,12]
CONGESTION       = ["Low","Moderate","High","Severe"]
CONGESTION_W     = [40,35,18,7]
DEVICE_MATCH     = ["Full Match","Partial","Legacy"]
DEVICE_W         = [55,30,15]
OVERAGE_FREQ     = ["Never","Occasional","Regular","Frequent"]
PLAN_CHANGE      = ["Stable","Upgraded Once","Upgraded Multiple","Downgraded","Mixed"]
PLAN_CHANGE_W    = [45,22,12,12,9]
SAT_PRED         = ["Highly Satisfied","Satisfied","Neutral","Dissatisfied","Highly Dissatisfied"]

FIELDNAMES = [
    "msisdn_hash","billing_account_id","cell_id","product_id","interaction_id",
    "first_name","last_name","gender","province",
    # fv_1
    "tenure_months_band","tenure_months","contract_type","payment_method_stability",
    "autopay_enrollment_flag","customer_lifetime_value_band","churn_risk_score_current",
    # fv_2
    "payment_punctuality_score","average_monthly_spend_band","billing_dispute_count_6m",
    "payment_method_change_frequency","arpu_trend_direction",
    # fv_3
    "average_data_speed_experience","call_drop_rate_experience","network_congestion_exposure",
    "device_capability_match","roaming_usage_flag",
    # fv_4
    "plan_utilization_rate","data_overage_frequency","bundle_affinity_score",
    "plan_change_frequency","value_added_service_uptake",
    # fv_5
    "recent_sentiment_score","complaint_escalation_flag","service_call_frequency_30d",
    "digital_channel_adoption_score","satisfaction_prediction",
    # extras
    "activation_date","churn_event_flag","churn_date",
]

output = "/home/claude/telecom_150k.csv"
print(f"Generating {N:,} rows -> {output}")
written = 0

with open(output,"w",newline="",encoding="utf-8") as fh:
    wr = csv.DictWriter(fh,fieldnames=FIELDNAMES); wr.writeheader()
    for cs in range(0,N,CHUNK):
        rows=[]
        for i in range(cs,min(cs+CHUNK,N)):
            rn_=i+1
            gender = random.choice(["Male","Female"])
            fname  = random.choice(MALE_FIRST if gender=="Male" else FEMALE_FIRST)
            lname  = random.choice(LAST_NAMES)
            province = wc(PROVINCES,PROV_W)

            # fv_1 — SubscriberLifecycleFeatures
            contract = wc(CONTRACT_TYPES, CONTRACT_W)
            tenure = int(clamp(round(abs(random.gauss(28,24))),1,180))
            if tenure<=3:   tb="New"
            elif tenure<=12: tb="Early"
            elif tenure<=36: tb="Established"
            elif tenure<=72: tb="Loyal"
            else:            tb="Champion"

            pay_stab = wc(PAY_STAB,[60,22,12,6])
            autopay  = random.random()<0.58
            clv_band = wc(CLV_BANDS, CLV_W)

            # Churn risk — higher for Month-to-Month, short tenure
            churn_base = 0.10
            if contract == "Month-to-Month": churn_base += 0.12
            elif contract == "Prepaid":      churn_base += 0.08
            if tenure < 6:   churn_base += 0.08
            elif tenure > 48: churn_base -= 0.05
            if autopay:      churn_base -= 0.04
            if clv_band in ("Dormant","Low"): churn_base += 0.06
            churn_score = rn(churn_base, 0.10, 0.001, 0.998)

            # fv_2 — BillingBehaviourFeatures
            punct_base = 75 - (15 if pay_stab=="Lapsed" else 0) - (8 if pay_stab=="Frequent Changes" else 0)
            punct = rn(punct_base, 18, 0, 100)
            arpu_band = wc(ARPU_BANDS, ARPU_W)
            dispute_cnt = int(clamp(round(abs(random.expovariate(1/0.28))),0,18))
            pmcf = wc(PAY_METH_CHANGE,[55,22,15,8])
            arpu_trend = wc(ARPU_TREND,[10,22,42,18,8])

            # fv_3 — NetworkExperienceFeatures
            speed_exp = wc(DATA_SPEED, DATA_SPEED_W)
            cdr = None if random.random()<0.086 else rn(0.018,0.024,0,0.98)
            congestion = wc(CONGESTION, CONGESTION_W)
            device_match = None if random.random()<0.116 else wc(DEVICE_MATCH, DEVICE_W)
            roaming = random.random()<0.08

            # fv_4 — ProductEngagementFeatures
            util_base = {"Dormant":0.18,"Low":0.38,"Mid":0.62,"High":0.82,"Premium":0.91}[clv_band]
            plan_util = rn(util_base,0.20,0,1.98)
            overage = wc(OVERAGE_FREQ,[45,28,16,11])
            bundle_aff = None if random.random()<0.082 else rn(0.34,0.24,0.01,0.99)
            plan_chg = wc(PLAN_CHANGE, PLAN_CHANGE_W)
            vas_count = int(clamp(round(abs(random.gauss(1.8,1.9))),0,18))

            # fv_5 — InteractionSentimentFeatures
            has_interactions = random.random()<0.824
            sent = None if not has_interactions else rn(0.08,0.38,-0.99,0.99)
            escalation = random.random()<0.06
            svc_calls = int(clamp(round(abs(random.gauss(1.1,1.6))),0,28))
            # Boost churn if escalation or high service calls
            if escalation: churn_score = min(0.998, churn_score + 0.15)
            if svc_calls >= 3: churn_score = min(0.998, churn_score + 0.08)
            digital_score = rn(42.1,28.4,0,100)
            sat_pred = None if not has_interactions else wc(SAT_PRED,[20,35,25,13,7])

            # Churn outcome
            churn_event = int(random.random()<churn_score)
            days_back = random.randint(30,365*5)
            act_dt = datetime(2026,3,14)-timedelta(days=days_back+tenure*30)
            activation_date = act_dt.strftime("%Y-%m-%d")
            churn_date = None
            if churn_event:
                cd = datetime(2026,3,14)-timedelta(days=random.randint(1,180))
                churn_date = cd.strftime("%Y-%m-%d")

            rows.append({
                "msisdn_hash": f"MSHASH{rn_:08d}",
                "billing_account_id": f"BACC{rn_:08d}",
                "cell_id": f"CELL{random.randint(1,5000):05d}",
                "product_id": f"PROD{random.randint(1,200):03d}",
                "interaction_id": f"INT{rn_:08d}",
                "first_name":fname,"last_name":lname,
                "gender":gender,"province":province,
                "tenure_months_band":tb,"tenure_months":tenure,
                "contract_type":contract,"payment_method_stability":pay_stab,
                "autopay_enrollment_flag":autopay,
                "customer_lifetime_value_band":clv_band,
                "churn_risk_score_current":churn_score,
                "payment_punctuality_score":punct,
                "average_monthly_spend_band":arpu_band,
                "billing_dispute_count_6m":dispute_cnt,
                "payment_method_change_frequency":pmcf,
                "arpu_trend_direction":arpu_trend,
                "average_data_speed_experience":speed_exp,
                "call_drop_rate_experience":cdr,
                "network_congestion_exposure":congestion,
                "device_capability_match":device_match,
                "roaming_usage_flag":roaming,
                "plan_utilization_rate":plan_util,
                "data_overage_frequency":overage,
                "bundle_affinity_score":bundle_aff,
                "plan_change_frequency":plan_chg,
                "value_added_service_uptake":vas_count,
                "recent_sentiment_score":sent,
                "complaint_escalation_flag":escalation,
                "service_call_frequency_30d":svc_calls,
                "digital_channel_adoption_score":digital_score,
                "satisfaction_prediction":sat_pred,
                "activation_date":activation_date,
                "churn_event_flag":churn_event,
                "churn_date":churn_date,
            })
        wr.writerows(rows); written+=len(rows)
        print(f"  {written:,}/{N:,}")

print(f"\nDone — {written:,} rows | {os.path.getsize(output)/1024/1024:.1f} MB")
# Quick QA
with open(output,newline="") as fh:
    rds=list(csv.DictReader(fh))
total=len(rds)
churn_rate=sum(1 for r in rds if r["churn_event_flag"]=="1")/total
autopay_rate=sum(1 for r in rds if r["autopay_enrollment_flag"]=="True")/total
print(f"  Churn rate:   {churn_rate:.1%}  (target ~18-25% for telecom)")
print(f"  Autopay rate: {autopay_rate:.1%} (target ~58%)")
